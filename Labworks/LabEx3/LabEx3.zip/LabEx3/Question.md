# Lab Exercise 3

    Implement
    the concept of inheritance, super, abstract and final keywords in your domain
