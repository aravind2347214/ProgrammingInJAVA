package Labworks.LabExam1.socialmedia;
public interface Post {
    public String createPost(String content);
    public void displayPost(String postId);
}
