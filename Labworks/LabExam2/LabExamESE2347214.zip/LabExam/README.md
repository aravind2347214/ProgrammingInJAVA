# Lab Exam 2 
Develop a Bank Management System using Java Swing components to create
an intuitive Bank Registration Form. The form should capture essential details
such as Bank Employee ID, Name, Age, Designation, and Department/section.
Ensure that the entered data is stored in a database table named 'Bank.'
Additionally, implement a search operation allowing users to retrieve bank
employee information based on either the name or department criteria.
